public class Zaznam {
    public int cislo;
    public int pocet;
    public Zaznam(int c) {
        pocet = 1;
        cislo = c;
    }
}