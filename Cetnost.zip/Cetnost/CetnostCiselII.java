public class CetnostCiselII {
	public static void main(String args[])
		Cetnosti cisla[] = new Cetnosti[100];
		java.util.Scanner sc = new java.util.Scanner(System.in);
		while (scanner.hasNextInt()) {
			int n = scanner.NextInt();
			for (int i = 0; i < pocet; i++) {
               			cisla[i].zapocitej(n);
                	}
		
		}
}
